package com.movieapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.movieapp.models.ERole;
import com.movieapp.models.Movie;
import com.movieapp.models.Role;
import com.movieapp.repository.MovieRepository;
import com.movieapp.repository.RoleRepository;

@SpringBootApplication
public class MovieappApplication implements CommandLineRunner {

	// Injecting the MovieRepository dependency
	@Autowired
	private MovieRepository movieRepository;
	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private MongoTemplate mongoTemplate;

	// Main method to launch the Spring Boot application
	public static void main(String[] args) {
		SpringApplication.run(MovieappApplication.class, args);
	}

	// Method executed after the application context is loaded and started
	@Override
	public void run(String... args) throws Exception {
		// Dropping the 'roles' collection if it exists
		mongoTemplate.dropCollection("roles");

		mongoTemplate.dropCollection("movie");
		
		// Creating Movie instances
		Movie movie1 = new Movie("Avatar", "PVR", 126, "Book ASAP");
		Movie movie2 = new Movie("Titanic", "PVR", 122, "Book ASAP");
		Movie movie3 = new Movie("Avengers", "IMAX", 107, "Book ASAP");
		Movie movie4 = new Movie("Bahubali", "IMAX", 107, "Book ASAP");
		Movie movie5 = new Movie("RRR", "IMAX", 107, "Book ASAP");
		Movie movie6 = new Movie("pushpa", "IMAX", 107, "Book ASAP");
		
	    // Saving the Movie instances to the database
		movieRepository.saveAll(List.of(movie1, movie2, movie3, movie4, movie5,movie6));

		Role admin = new Role(ERole.ROLE_ADMIN);
		Role user = new Role(ERole.
				ROLE_USER);

		roleRepository.saveAll(List.of(admin, user));
	}
}
